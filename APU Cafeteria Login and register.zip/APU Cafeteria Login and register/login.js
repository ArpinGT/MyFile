document.addEventListener("DOMContentLoaded", function () {
    // Get the form element
    const loginForm = document.querySelector("form");
  
    // Add a submit event listener to the form
    loginForm.addEventListener("submit", function (event) {
      // Prevent the default form submission behavior
      event.preventDefault();
  
      // You can add your custom login logic here if needed
      // For example, you can send an AJAX request to handle the login process
  
      // Once your custom logic is done, you can redirect the user or perform other actions
      // For now, let's just log a message
      console.log("Form submission prevented");
    });
  });
  